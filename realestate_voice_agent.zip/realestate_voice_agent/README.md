# RealEstate Hub — Production-Grade AI Voice Agent

A production-oriented real-estate conversational AI reference implementation for the Week 4 Capstone.

## What is included

- Human-like UrduLish conversation design
- LangGraph stateful orchestration
- Structured property retrieval with SQLite
- Semantic RAG with ChromaDB (with a lightweight fallback for demo mode)
- Property recommendation engine
- Booking, rescheduling and cancellation workflow
- Mock Google Calendar, email and CRM services
- FastAPI backend
- Voice pipeline adapter interfaces for STT/TTS/telephony
- Prompt-injection guardrails
- Evaluation suite and metrics
- Docker deployment
- CI test workflow
- Architecture, API, operations and demo documentation

The capstone brief explicitly asks for a complete LangGraph workflow, RAG/vector DB, structured property database, Calendar, email, CRM-ready logging, FastAPI, evaluation, security testing, monitoring and Dockerized deployment. See the original brief for the full requirements. 

## Quick start — no API keys required

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs`.

The default mode is **mock/demo mode**, so the application can be demonstrated without OpenAI, Fish Audio, Deepgram, Google Calendar or Gmail credentials.

## Example API calls

### Chat

```bash
curl -X POST http://127.0.0.1:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"session_id":"demo-1","message":"Mera budget 3 crore hai aur DHA mein family ke liye 4 bedroom house chahiye."}'
```

### Property search

```bash
curl -X POST http://127.0.0.1:8000/properties/search \
  -H "Content-Type: application/json" \
  -d '{"budget_max":35000000,"city":"Lahore","area":"DHA","bedrooms":4}'
```

### Appointment

```bash
curl -X POST http://127.0.0.1:8000/appointments \
  -H "Content-Type: application/json" \
  -d '{"client_name":"Ali Khan","phone":"03001234567","property_id":"P001","date":"2026-10-02","time":"15:00","notes":"Family visit"}'
```

## Connect production providers

Set environment variables in `.env` and replace the mock adapters with provider implementations:

- `OPENAI_API_KEY`
- `DEEPGRAM_API_KEY`
- `FISH_AUDIO_API_KEY`
- `GOOGLE_CALENDAR_CREDENTIALS_JSON`
- `SMTP_*` or Gmail/Graph credentials
- PostgreSQL/Redis/managed Chroma/Pinecone credentials as required

The capstone brief recommends Fish Audio, Deepgram, LangGraph, ChromaDB/Pinecone, n8n, Google Calendar, email, FastAPI and Docker. This repository keeps provider boundaries clean so those services can be swapped without rewriting the agent logic.

## Project structure

```text
app/
  main.py                  FastAPI entry point
  config.py                environment configuration
  agent/                   LangGraph state and nodes
  rag/                     semantic retrieval
  tools/                   property/calendar/email/CRM tools
  services/                business services
  models/                  Pydantic request models
  api/                     API routes

data/
  properties.json          demo property inventory
  knowledge_base.json      verified company knowledge

tests/
  test_agent.py            conversation/guardrail tests
  test_properties.py       structured retrieval tests
  test_appointments.py     booking tests

docs/
  ARCHITECTURE.md
  API.md
  EVALUATION.md
  DEMO_SCRIPT.md
  OPERATIONS.md
  SYSTEM_PROMPT.md
```

## Important production notes

1. Never invent availability, prices, property IDs, employee names or appointment slots.
2. Production calendar/email calls must be idempotent and authenticated.
3. Store secrets only in a secret manager/environment variables.
4. Add consent and retention controls before recording real calls.
5. Use human escalation for complaints, legal/financial advice, uncertain property facts and requests outside the agent's authority.
6. For production voice, implement streaming STT -> LLM -> TTS and interruption handling.

## Capstone coverage

| Requirement | Implementation |
|---|---|
| UrduLish persona | `docs/SYSTEM_PROMPT.md`, agent nodes |
| RAG | `app/rag/retriever.py` |
| Structured SQL retrieval | `app/services/property_service.py` |
| Recommendations | `app/services/recommendation.py` |
| LangGraph | `app/agent/graph.py` |
| Calendar | `app/tools/calendar.py` |
| Email | `app/tools/email.py` |
| CRM | `app/tools/crm.py` |
| FastAPI | `app/main.py` |
| Security tests | `tests/test_agent.py` |
| Evaluation | `docs/EVALUATION.md`, `tests/` |
| Docker | `Dockerfile`, `docker-compose.yml` |
| CI/CD | `.github/workflows/test.yml` |
| Demo | `docs/DEMO_SCRIPT.md` |

## Run tests

```bash
pytest -q
```

The demo property inventory is seeded into `data/properties.db` automatically on first access. For a real deployment, move the same schema/data into PostgreSQL.
