import pytest
from app.services.appointment_service import AppointmentService
from app.models.schemas import AppointmentCreate

def test_booking_and_conflict():
    service = AppointmentService()
    req = AppointmentCreate(client_name="Ali", phone="0300", property_id="P001", date="2026-10-02", time="15:00")
    first = service.create(req)
    assert first["event_id"]
    with pytest.raises(ValueError): service.create(req)

def test_cancel():
    service = AppointmentService()
    req = AppointmentCreate(client_name="Ali", phone="0300", property_id="P001", date="2026-10-03", time="15:00")
    event = service.create(req)
    deleted = service.cancel(event["event_id"])
    assert deleted["event_id"] == event["event_id"]
