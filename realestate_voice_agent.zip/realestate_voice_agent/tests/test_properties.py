from app.services.property_service import PropertyService

def test_budget_filter():
    rows = PropertyService().search(city="Lahore", budget_max=25_000_000)
    assert rows and all(p["price"] <= 25_000_000 for p in rows)

def test_unavailable_not_returned():
    assert all(p["available"] for p in PropertyService().search())
