from datetime import datetime

class CalendarTool:
    def __init__(self): self.events = {}

    def is_available(self, date, time):
        return not any(e["date"] == date and e["time"] == time for e in self.events.values())

    def create(self, payload):
        if not self.is_available(payload["date"], payload["time"]):
            raise ValueError("Requested appointment slot is unavailable")
        event_id = f"evt-{len(self.events)+1:04d}"
        self.events[event_id] = {**payload, "event_id": event_id, "created_at": datetime.utcnow().isoformat()}
        return self.events[event_id]

    def update(self, event_id, date, time):
        if event_id not in self.events: raise KeyError("Appointment not found")
        if not self.is_available(date, time): raise ValueError("Requested appointment slot is unavailable")
        self.events[event_id].update(date=date, time=time)
        return self.events[event_id]

    def cancel(self, event_id):
        if event_id not in self.events: raise KeyError("Appointment not found")
        return self.events.pop(event_id)
