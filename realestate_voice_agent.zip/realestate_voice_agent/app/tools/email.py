class EmailTool:
    def __init__(self): self.outbox = []
    def send(self, to, subject, body):
        message = {"to": to, "subject": subject, "body": body}
        self.outbox.append(message)
        return {"status": "queued", **message}
