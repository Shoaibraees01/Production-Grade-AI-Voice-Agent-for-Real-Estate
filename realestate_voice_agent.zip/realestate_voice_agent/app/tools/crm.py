class CRMTool:
    def __init__(self): self.records = []
    def log_call(self, session_id, transcript, profile):
        record = {"session_id": session_id, "transcript": transcript, "profile": profile}
        self.records.append(record)
        return record
