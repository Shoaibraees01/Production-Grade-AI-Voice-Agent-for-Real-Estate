from pydantic import BaseModel, Field
from typing import Optional, List

class ChatRequest(BaseModel):
    session_id: str
    message: str

class ChatResponse(BaseModel):
    session_id: str
    response: str
    intent: str
    recommendations: List[dict] = []

class PropertySearch(BaseModel):
    budget_max: Optional[int] = None
    city: Optional[str] = None
    area: Optional[str] = None
    bedrooms: Optional[int] = None
    purpose: Optional[str] = None
    property_type: Optional[str] = None

class AppointmentCreate(BaseModel):
    client_name: str
    phone: str
    property_id: str
    date: str
    time: str
    employee: str = "Demo Sales Executive"
    notes: str = ""

class AppointmentUpdate(BaseModel):
    date: Optional[str] = None
    time: Optional[str] = None
    notes: Optional[str] = None

class VoiceRequest(BaseModel):
    session_id: str
    audio_text: str = Field(description="Demo-mode transcript. Replace with real STT audio ingestion in production.")
