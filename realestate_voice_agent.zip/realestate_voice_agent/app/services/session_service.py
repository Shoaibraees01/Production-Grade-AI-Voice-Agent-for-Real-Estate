from typing import Dict
from ..agent.graph import GRAPH
from ..tools.crm import CRMTool

class SessionService:
    def __init__(self): self.sessions: Dict[str, dict] = {}; self.crm = CRMTool()
    def chat(self, session_id, message):
        old = self.sessions.get(session_id, {"messages": [], "user_profile": {}, "property_preferences": {}, "tool_outputs": {}})
        state = {**old, "session_id": session_id, "messages": old["messages"] + [{"role":"user","content":message}]}
        result = GRAPH.invoke(state)
        result["messages"] = result["messages"] + [{"role":"assistant","content":result["response"]}]
        self.sessions[session_id] = result
        self.crm.log_call(session_id, result["messages"], result.get("property_preferences", {}))
        return result

session_service = SessionService()
