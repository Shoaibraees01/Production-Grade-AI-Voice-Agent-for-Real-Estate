from ..tools.calendar import CalendarTool
from ..tools.email import EmailTool
from ..services.property_service import PropertyService

class AppointmentService:
    def __init__(self):
        self.calendar = CalendarTool(); self.email = EmailTool(); self.properties = PropertyService(); self.records = {}
    def create(self, payload):
        data = payload.model_dump() if hasattr(payload, "model_dump") else payload
        if not self.properties.availability(data["property_id"]): raise ValueError("Property is unavailable")
        event = self.calendar.create(data)
        self.records[event["event_id"]] = event
        self.email.send(payload.employee.replace(" ", ".").lower()+"@realestatehub.demo", "New property visit", str(event))
        return event
    def reschedule(self, event_id, date, time):
        event = self.calendar.update(event_id, date, time); self.records[event_id] = event
        self.email.send("sales@realestatehub.demo", "Appointment rescheduled", str(event)); return event
    def cancel(self, event_id):
        event = self.calendar.cancel(event_id); self.records.pop(event_id, None)
        self.email.send("sales@realestatehub.demo", "Appointment cancelled", str(event)); return event

appointment_service = AppointmentService()
