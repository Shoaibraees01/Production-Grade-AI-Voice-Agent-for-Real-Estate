import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data" / "properties.json"
DB = ROOT / "data" / "properties.db"


def _connect():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS properties (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            city TEXT NOT NULL,
            area TEXT NOT NULL,
            property_type TEXT NOT NULL,
            price INTEGER NOT NULL,
            bedrooms INTEGER NOT NULL,
            bathrooms INTEGER NOT NULL,
            amenities TEXT NOT NULL,
            purpose TEXT NOT NULL,
            available INTEGER NOT NULL,
            developer TEXT NOT NULL
        )
    """)
    if conn.execute("SELECT COUNT(*) FROM properties").fetchone()[0] == 0:
        for p in json.loads(DATA.read_text(encoding="utf-8")):
            conn.execute(
                "INSERT INTO properties VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (p["id"], p["title"], p["city"], p["area"], p["property_type"], p["price"],
                 p["bedrooms"], p["bathrooms"], json.dumps(p["amenities"]), json.dumps(p["purpose"]),
                 int(p["available"]), p["developer"]),
            )
        conn.commit()
    return conn


def _row(row):
    if not row: return None
    d = dict(row)
    d["amenities"] = json.loads(d["amenities"])
    d["purpose"] = json.loads(d["purpose"])
    d["available"] = bool(d["available"])
    return d


class PropertyService:
    def search(self, **filters):
        conn = _connect()
        clauses = ["available = 1"]
        args = []
        if filters.get("budget_max") is not None:
            clauses.append("price <= ?"); args.append(filters["budget_max"])
        if filters.get("bedrooms") is not None:
            clauses.append("bedrooms >= ?"); args.append(filters["bedrooms"])
        if filters.get("city"):
            clauses.append("LOWER(city) = LOWER(?)"); args.append(filters["city"])
        if filters.get("area"):
            clauses.append("LOWER(area) LIKE LOWER(?)"); args.append(f"%{filters['area']}%")
        if filters.get("property_type"):
            clauses.append("LOWER(property_type) = LOWER(?)"); args.append(filters["property_type"])
        # Purpose/amenity are JSON fields in SQLite demo mode; filter them after exact SQL filtering.
        rows = [_row(r) for r in conn.execute(f"SELECT * FROM properties WHERE {' AND '.join(clauses)}", args).fetchall()]
        conn.close()
        if filters.get("purpose"):
            purpose = filters["purpose"].lower()
            rows = [p for p in rows if purpose in [x.lower() for x in p["purpose"]]]
        return rows

    def get(self, property_id):
        conn = _connect()
        row = conn.execute("SELECT * FROM properties WHERE id = ?", (property_id,)).fetchone()
        conn.close()
        return _row(row)

    def availability(self, property_id):
        p = self.get(property_id)
        return bool(p and p["available"])
