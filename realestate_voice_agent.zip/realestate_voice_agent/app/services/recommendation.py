from .property_service import PropertyService

class RecommendationEngine:
    def __init__(self): self.properties = PropertyService()

    def recommend(self, preferences):
        candidates = self.properties.search(**preferences)
        budget = preferences.get("budget_max")
        def score(p):
            s = 0
            if budget: s += max(0, 100 - abs(budget - p["price"]) / max(budget, 1) * 100)
            if preferences.get("city") and p["city"].lower() == preferences["city"].lower(): s += 30
            if preferences.get("area") and preferences["area"].lower() in p["area"].lower(): s += 30
            if preferences.get("bedrooms") and p["bedrooms"] >= preferences["bedrooms"]: s += 20
            if preferences.get("purpose") and preferences["purpose"].lower() in [x.lower() for x in p["purpose"]]: s += 20
            return s
        return sorted(candidates, key=score, reverse=True)[:3]
