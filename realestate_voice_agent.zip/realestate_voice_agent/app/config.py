from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "demo"
    openai_api_key: str = ""
    deepgram_api_key: str = ""
    fish_audio_api_key: str = ""
    google_calendar_credentials_json: str = ""
    database_url: str = "sqlite:///./realestate.db"
    chroma_dir: str = "./.chroma"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
