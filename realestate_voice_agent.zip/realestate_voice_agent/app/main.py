from fastapi import FastAPI
from .api.routes import router

app = FastAPI(title="RealEstate Hub AI Voice Agent", version="1.0.0", description="Production-oriented UrduLish real estate conversational AI")
app.include_router(router)
