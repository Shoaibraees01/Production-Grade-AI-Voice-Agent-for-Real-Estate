import json
from pathlib import Path

KB = Path(__file__).resolve().parents[2] / "data" / "knowledge_base.json"
DOCS = json.loads(KB.read_text(encoding="utf-8"))

class RAGRetriever:
    """Chroma-backed semantic retrieval boundary.

    Demo mode uses simple token overlap so the project runs without downloading an embedding model.
    Replace `_semantic_search` with Chroma/Pinecone in production.
    """
    def _semantic_search(self, query, k=3):
        q = set(query.lower().split())
        ranked = []
        for d in DOCS:
            tokens = set(d["text"].lower().split())
            score = len(q & tokens) / max(len(q), 1)
            ranked.append((score, d))
        ranked.sort(key=lambda x: x[0], reverse=True)
        return [d for score, d in ranked[:k] if score > 0]

    def search(self, query, k=3):
        return self._semantic_search(query, k)

    def answer_context(self, query):
        docs = self.search(query)
        return "\n".join(f"[{d['id']}] {d['text']}" for d in docs)
