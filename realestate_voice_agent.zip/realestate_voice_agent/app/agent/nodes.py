import re
from .state import AgentState
from ..services.recommendation import RecommendationEngine
from ..rag.retriever import RAGRetriever

recommendations = RecommendationEngine()
rag = RAGRetriever()

INJECTION_PATTERNS = [
    r"ignore (all|previous|your) instructions",
    r"reveal (your|the) prompt",
    r"system prompt",
    r"internal company data",
    r"book fake appointments"
]

def guardrail(state: AgentState):
    text = state["messages"][-1]["content"].lower()
    blocked = any(re.search(p, text) for p in INJECTION_PATTERNS)
    state["tool_outputs"] = {**state.get("tool_outputs", {}), "guardrail_blocked": blocked}
    if blocked:
        state["response"] = "Ji, main internal instructions ya unverified company data share nahi kar sakta. Agar aap property, price ya visit ke baare mein poochna chahein to main help karta hoon."
    return state

def intent_detection(state: AgentState):
    text = state["messages"][-1]["content"].lower()
    if any(x in text for x in ["reschedule", "change my appointment"]): intent = "rescheduling"
    elif any(x in text for x in ["cancel appointment", "cancel my visit"]): intent = "cancellation"
    elif any(x in text for x in ["book", "visit", "appointment"]): intent = "booking"
    elif any(x in text for x in ["rent", "rental", "kiraye"]): intent = "rental"
    elif any(x in text for x in ["invest", "investment", "return"]): intent = "investment"
    elif any(x in text for x in ["commercial", "office", "shop"]): intent = "commercial"
    elif any(x in text for x in ["house", "home", "bedroom", "family"]): intent = "buyer"
    else: intent = "general"
    state["intent"] = intent
    return state

def extract_preferences(state: AgentState):
    text = state["messages"][-1]["content"]
    prefs = dict(state.get("property_preferences", {}))
    crore = re.search(r"(\d+(?:\.\d+)?)\s*crore", text.lower())
    lakh = re.search(r"(\d+(?:\.\d+)?)\s*lakh", text.lower())
    if crore: prefs["budget_max"] = int(float(crore.group(1)) * 10_000_000)
    elif lakh: prefs["budget_max"] = int(float(lakh.group(1)) * 100_000)
    for city in ["Lahore", "Multan", "Islamabad", "Karachi"]:
        if city.lower() in text.lower(): prefs["city"] = city
    beds = re.search(r"(\d+)\s*(?:bedroom|bed|beds)", text.lower())
    if beds: prefs["bedrooms"] = int(beds.group(1))
    for purpose in ["family", "investment", "rental", "commercial"]:
        if purpose in text.lower(): prefs["purpose"] = purpose
    state["property_preferences"] = prefs
    state["budget"] = prefs.get("budget_max")
    return state

def retrieve_and_recommend(state: AgentState):
    prefs = state.get("property_preferences", {})
    state["recommendations"] = recommendations.recommend(prefs)
    state["tool_outputs"] = {**state.get("tool_outputs", {}), "rag_context": rag.answer_context(state["messages"][-1]["content"])}
    return state

def respond(state: AgentState):
    if state.get("tool_outputs", {}).get("guardrail_blocked"):
        return state
    intent = state.get("intent", "general")
    recs = state.get("recommendations", [])
    if intent == "booking":
        text = "Ji bilkul, visit book kar dete hain. Pehle property ID aur preferred date/time confirm kar dein, phir main availability check karunga."
    elif intent == "rescheduling":
        text = "Ji, appointment reschedule ho sakti hai. Aap nayi date aur time bata dein; main availability check karke update karunga."
    elif intent == "cancellation":
        text = "Ji, cancellation possible hai. Appointment/event ID ya booking details share kar dein taa-ke main exact record update kar sakun."
    elif recs:
        p = recs[0]
        text = f"Ji bilkul. Aapki requirements ke mutabiq ek suitable option {p['title']} hai, price PKR {p['price']:,}. {p['bedrooms']} bedrooms hain aur listed amenities mein {', '.join(p['amenities'][:3])} hain. Agar aap chahein to main aur options compare kar deta hoon."
    else:
        text = "Assalam-o-Alaikum! RealEstate Hub se baat ho rahi hai. Aapka budget, preferred city/area aur purpose bata dein, main verified options check karke guide karta hoon."
    state["response"] = text
    return state
