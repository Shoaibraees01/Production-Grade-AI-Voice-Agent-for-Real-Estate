try:
    from langgraph.graph import StateGraph, END
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False

from .state import AgentState
from .nodes import guardrail, intent_detection, extract_preferences, retrieve_and_recommend, respond

class DemoGraph:
    """Minimal fallback used only when LangGraph is not installed in demo/test environments."""
    def invoke(self, state):
        state = guardrail(state)
        if not state.get("tool_outputs", {}).get("guardrail_blocked"):
            state = intent_detection(state)
            state = extract_preferences(state)
            state = retrieve_and_recommend(state)
        return respond(state)

def build_graph():
    if not LANGGRAPH_AVAILABLE:
        return DemoGraph()
    g = StateGraph(AgentState)
    g.add_node("guardrail", guardrail)
    g.add_node("intent", intent_detection)
    g.add_node("preferences", extract_preferences)
    g.add_node("retrieve", retrieve_and_recommend)
    g.add_node("respond", respond)
    g.set_entry_point("guardrail")
    def route(state):
        return "respond" if state.get("tool_outputs", {}).get("guardrail_blocked") else "intent"
    g.add_conditional_edges("guardrail", route, {"respond":"respond", "intent":"intent"})
    g.add_edge("intent", "preferences")
    g.add_edge("preferences", "retrieve")
    g.add_edge("retrieve", "respond")
    g.add_edge("respond", END)
    return g.compile()

GRAPH = build_graph()
