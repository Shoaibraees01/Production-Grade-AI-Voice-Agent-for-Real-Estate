from typing import TypedDict, List, Dict, Any

class AgentState(TypedDict, total=False):
    session_id: str
    messages: List[Dict[str, str]]
    user_profile: Dict[str, Any]
    property_preferences: Dict[str, Any]
    budget: int | None
    intent: str
    tool_outputs: Dict[str, Any]
    appointment_status: str
    response: str
    recommendations: List[dict]
