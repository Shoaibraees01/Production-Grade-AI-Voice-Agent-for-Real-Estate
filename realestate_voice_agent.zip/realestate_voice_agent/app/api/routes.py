from fastapi import APIRouter, HTTPException
from ..models.schemas import ChatRequest, ChatResponse, PropertySearch, AppointmentCreate, AppointmentUpdate, VoiceRequest
from ..services.session_service import session_service
from ..services.property_service import PropertyService
from ..services.appointment_service import appointment_service

router = APIRouter()
properties = PropertyService()

@router.get("/health")
def health(): return {"status":"ok","mode":"demo"}

@router.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    result = session_service.chat(req.session_id, req.message)
    return ChatResponse(session_id=req.session_id, response=result["response"], intent=result.get("intent","general"), recommendations=result.get("recommendations", []))

@router.post("/voice")
def voice(req: VoiceRequest):
    # Demo adapter: production replaces this text field with streamed audio STT/TTS.
    result = session_service.chat(req.session_id, req.audio_text)
    return {"session_id": req.session_id, "transcript": req.audio_text, "response_text": result["response"], "tts_provider":"mock"}

@router.post("/properties/search")
def search(req: PropertySearch): return properties.search(**req.model_dump())

@router.get("/properties/{property_id}")
def get_property(property_id: str):
    p = properties.get(property_id)
    if not p: raise HTTPException(404, "Property not found")
    return p

@router.post("/appointments")
def create_appointment(req: AppointmentCreate):
    try: return appointment_service.create(req)
    except (ValueError, KeyError) as e: raise HTTPException(409, str(e))

@router.patch("/appointments/{event_id}")
def reschedule(event_id: str, req: AppointmentUpdate):
    if not req.date or not req.time: raise HTTPException(400, "date and time are required")
    try: return appointment_service.reschedule(event_id, req.date, req.time)
    except (ValueError, KeyError) as e: raise HTTPException(409, str(e))

@router.delete("/appointments/{event_id}")
def cancel(event_id: str):
    try: return appointment_service.cancel(event_id)
    except KeyError as e: raise HTTPException(404, str(e))
