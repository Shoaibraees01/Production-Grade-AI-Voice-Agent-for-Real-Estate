# Architecture

```text
Incoming Call
     |
     v
Telephony -> Streaming STT (Deepgram/Whisper)
     |
     v
LangGraph State Machine
  |       |        |
  |       |        +--> Structured SQL Property Search (SQLite/PostgreSQL in production)
  |       +-----------> RAG / ChromaDB (brochures, FAQs, descriptions)
  +-------------------> Conversation Memory
     |
     v
Recommendation / Objection Handling / Booking
     |
     +--> Google Calendar
     +--> Email
     +--> CRM
     |
     v
Streaming TTS (Fish Audio)
     |
     v
Caller
```

## State

- conversation history
- user profile
- property preferences
- budget
- intent
- tool outputs
- appointment status

## Retrieval split

Structured SQL retrieval is the source of truth for mutable exact values such as price, availability, plot size and employee identity. Semantic RAG is used for brochures, descriptions and FAQs. This prevents a semantic model from being treated as the source of truth for transactional fields.

## Workflow

`Call -> Intent -> Property Match -> Appointment -> Calendar -> Email -> CRM Update`

All external actions should be idempotent and retried with bounded backoff in production.
