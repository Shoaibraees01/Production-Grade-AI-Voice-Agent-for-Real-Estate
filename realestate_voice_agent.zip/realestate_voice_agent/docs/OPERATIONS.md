# Operations & Maintenance

## Monitoring

Track:
- average and p95 end-to-end latency
- STT latency
- LLM latency
- TTS first-byte latency
- voice quality failures
- API failures
- calendar failures
- email failures
- booking success
- RAG misses
- hallucination rate

## Suggested operational alerts

- p95 voice response latency > 2.0 seconds for 10 minutes
- calendar failure rate > 2% over 15 minutes
- email failure rate > 2% over 15 minutes
- health endpoint failure for 2 consecutive checks
- hallucination/grounding regression in scheduled evaluation

## Maintenance

- Weekly review of failed calls and retrieval misses
- Weekly refresh of mutable property inventory
- Prompt changes only through version control and evaluation
- Monthly security review
- Regular database backups
- Rotate credentials using a secret manager

## Deployment

Use Docker and a managed runtime such as Railway, Render or AWS. Put FastAPI behind HTTPS and authentication/rate limiting before exposing it to real callers.
