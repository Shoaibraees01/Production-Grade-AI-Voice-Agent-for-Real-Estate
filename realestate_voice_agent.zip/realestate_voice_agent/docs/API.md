# API Documentation

Base URL: `http://localhost:8000`

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/chat` | Text simulation of voice conversation |
| POST | `/voice` | Demo voice adapter using transcript input |
| POST | `/properties/search` | Structured property search |
| GET | `/properties/{id}` | Verified property detail |
| POST | `/appointments` | Create appointment |
| PATCH | `/appointments/{event_id}` | Reschedule appointment |
| DELETE | `/appointments/{event_id}` | Cancel appointment |

FastAPI automatically exposes Swagger at `/docs` and OpenAPI JSON at `/openapi.json`.
