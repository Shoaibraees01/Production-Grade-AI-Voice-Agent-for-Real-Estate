# Day 1 Design Deliverables

## Conversation flows

```mermaid
flowchart TD
A[Incoming Call] --> B[Greeting + Consent]
B --> C{Intent}
C -->|Buyer| D[Budget + City + Area + Bedrooms + Purpose]
C -->|Rental| E[Rent Budget + Location + Bedrooms]
C -->|Commercial| F[Property Type + Location + Budget + Purpose]
C -->|Investment| G[Budget + Risk/Goal + Location]
C -->|Returning| H[Load Context + Confirm Preferences]
C -->|Reschedule| I[Find Appointment + Check New Slot]
C -->|Cancel| J[Find Appointment + Confirm Cancellation]
D --> K[Structured Property Search + RAG]
E --> K
F --> K
G --> K
H --> K
K --> L[Recommendation / Objection Handling]
L --> M{Visit?}
M -->|Yes| N[Availability Check]
N --> O[Calendar + Email + CRM]
M -->|No| P[Follow-up / Goodbye]
I --> O
J --> P
O --> P
```

## Voice architecture

Speech-to-Text -> intent/reasoning -> tools/retrieval -> response -> Text-to-Speech -> telephony. The production path should stream each stage and support barge-in/interruption rather than waiting for full turns.

## UrduLish persona

- Pakistani conversational style
- Professional, warm, patient and persuasive
- Use natural acknowledgements: `Ji bilkul`, `Acha, samajh gaya`, `Ek second sir, main check karta hoon`
- Avoid literal translation from English
- Keep factual claims grounded in company data
